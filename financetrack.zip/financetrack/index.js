const express = require('express');
const connectDB =require('./dbconfig/dbconfig.js');
const route = require('./router/registerroute.js');
// dotenv.config(dotenv)
const path = require('path');
const { scheduleNotificationsCron  } = require('./cronjob.js');
const {sendEmailNotification} = require('./notificationservice.js');

const app = express();

// Set the view engine to EJS
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
// Set the path for views (optional)
app.set('views', path.join(__dirname, 'views'));
// Static folder for styles, images, etc.
app.use(express.static(path.join(__dirname, 'public')));

var port = 8001;

connectDB();

app.use(express.json());
// app.use(route);
// Use your router
app.use('/', route);
// Start the cron job for notifications
scheduleNotificationsCron();
// sendEmailNotification();
app.listen(port,() =>{
    (`server is running on http://localhost:${port}`)
});