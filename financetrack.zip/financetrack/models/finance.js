const mongoose = require("mongoose");

const financialGoalSchema = new mongoose.Schema({
  userId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "Register", 
    required: true 
  }, // Link to the user who set the goal
  name: { type: String, required: true }, // Goal name (e.g., "Vacation Savings")
  targetAmount: { type: Number, required: true }, // Target savings amount
  currentProgress: { type: Number, default: 0 }, // Current saved amount
  startDate: { type: Date, required: true }, // Goal start date
  endDate: { type: Date, required: true }, // Goal end date
  category: { type: String, default: "General" }, // Goal category (optional)
  createdAt: { type: Date, default: Date.now }, // Record creation date
});

module.exports = mongoose.model("FinancialGoal", financialGoalSchema);
