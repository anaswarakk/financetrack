// models/Expense.js
const mongoose = require('mongoose');

const expenseSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'Register', required: true }, // Link to the user
    amount: { type: Number, required: true },
    category: { type: String, required: true }, // e.g., Food, Travel, etc.
    description: { type: String, default: '' },
    date: { type: Date, required: true }, // Date of the expense record
}, { timestamps: true }); // Automatically add createdAt and updatedAt fields

module.exports = mongoose.model('Expense', expenseSchema);
