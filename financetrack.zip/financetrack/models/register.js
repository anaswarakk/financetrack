const mongoose = require('mongoose');


const registerSchema =new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    profilePicture: { type: String, default: "" },  // Optional: Store image URL or file path
    phoneNumber: { type: String, default: "" },     // Optional
    address: { type: String, default: "" },  
    createdAt: {
        type: Date,
        default: Date.now,
    },
})

const register = mongoose.model("register", registerSchema);

module.exports = register;