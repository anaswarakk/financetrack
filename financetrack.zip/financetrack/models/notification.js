const mongoose = require("mongoose");

const NotificationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "Register", required: true }, // Reference to the user
  title: { type: String, required: true }, // Notification title
  message: { type: String, required: true }, // Notification message
  date: Date,
  type: { type: String, enum: ["email", "sms"] }, // Type of notification (email or sms)
  isSent: { type: Boolean, default: false },
  email: String, // Recipient email (for email notifications)
  phone: String, // Recipient phone (for SMS notifications)
});

module.exports = mongoose.model("Notification", NotificationSchema);
