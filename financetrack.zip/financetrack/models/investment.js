const mongoose = require("mongoose");

const InvestmentSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "Register", required: true },
  investment_type: { type: String, required: true },
  amount: { type: Number, required: true },
  date: { type: Date, required: true },
  maturity_date: { type: Date, required: true }, // Maturity date for the investment
  description: { type: String },
  current_value: { type: Number, default: 0 },
  returns: { type: Number, default: 0 },
  is_notified: { type: Boolean, default: false }, // Whether a notification has been sent
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Investment", InvestmentSchema);
