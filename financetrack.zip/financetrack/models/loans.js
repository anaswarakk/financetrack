const mongoose = require('mongoose');

const loanSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'Register', required: true }, // Link to the user
  principal: { type: Number, required: true }, // Loan principal amount
  interestRate: { type: Number, required: true }, // Annual interest rate in percentage
  tenure: { type: Number, required: true }, // Tenure in months
  startDate: { type: Date, required: true }, // Loan start date
  dueDate: { type: Date, required: true }, // Next installment due date
  payments: [
    {
      date: { type: Date, required: true }, // Payment date
      amount: { type: Number, required: true } // Payment amount
    }
  ],
  status: {
    type: String,
    enum: ['active', 'closed', 'defaulted'],
    default: 'active'
  },
  createdAt: { type: Date, default: Date.now },
});

const Loan = mongoose.model('Loan', loanSchema);

module.exports = Loan;
