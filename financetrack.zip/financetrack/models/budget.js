const mongoose = require('mongoose');

const budgetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Register',  // Link to the Register model (user)
    required: true,
  },
  category: {
    type: String,
    required: true,
    enum: ['Groceries', 'Entertainment', 'Utilities', 'Transport', 'Healthcare', 'Savings', 'Others','Food'], // Predefined categories, can be expanded
  },
  amount: {
    type: Number,
    required: true,
    min: [0, 'Budget amount cannot be negative'], // Ensure the budget is not negative
  },
  startDate: {
    type: Date,
    required: true,
  },
  endDate: {
    type: Date,
    required: true,
  },
  description: {
    type: String,
    default: '',
  },
}, { timestamps: true });  // Automatically add createdAt and updatedAt fields

module.exports = mongoose.model('Budget', budgetSchema);
