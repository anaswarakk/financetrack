const mongoose = require('mongoose');

const incomeSchema = new mongoose.Schema({
    userId: {
         type: mongoose.Schema.Types.ObjectId, ref: 'Register',
          required: true
         }, // Link to the user
    amount: { 
        type: Number, required: true
     },
    category: {
         type: String, required: true 
        }, // e.g., Salary, Investment, etc.
    description: {
         type: String, default: '' 
        },
    date: { 
        type: Date, required: true 
    }, // Date of the income record
}, { timestamps: true }); // Automatically add createdAt and updatedAt fields

module.exports = mongoose.model('Income', incomeSchema);