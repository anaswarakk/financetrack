const express = require('express');
const register = require('../models/register.js');
const Budget = require('../models/budget.js');
const FinancialGoal = require('../models/finance.js');

const createBudget = async (req, res) => {
    const { category, amount, startDate, endDate, description } = req.body;

    try {
        console.log("try")
        const budget = new Budget({
            userId: req.userId,// Extracted from JWT token
            category,
            amount,
            startDate,
            endDate,
            description,
        });

        await budget.save();
        res.status(201).json({ message: 'Budget record added', budget });
    } catch (error) {
        console.error('Error adding Budget:', error);
        res.status(500).json({ message: 'Internal server error' });
    }

}



const getUserBudgets = async (req,res) => {
    try{
        const userId = req.userId;

        const budgets = await Budget.find({ userId }); // Sort by date
        res.json({ budgets });
    }catch(error){
       console.error("Error fetching incomes:", error);
        res.status(500).json({ message: "An error occurred while fetching incomes." });
    }
}

const updateBudget = async (req, res) => {
    const { id } = req.params;
    const { amount, startDate, category, endDate, description } = req.body;

    try {
        const budget = await Budget.findOneAndUpdate(
            { _id: id },
            { amount, category, startDate, endDate, description }, // Fields to update
            { new: true } // Return the updated document
        );

        if (!budget) {
            return res.status(404).json({ message: 'Budget not found' });
        }

        res.status(200).json({ message: 'Budget updated successfully', budget });
    } catch (err) {
        res.status(500).json({ message: 'Error updating budget', error: err.message });
    }
}

const createGoal = async (req, res) => {
    try {
        const { name, targetAmount, startDate, endDate, category } = req.body;

        // Validate request body
        if (!name || !targetAmount || !startDate || !endDate) {
            return res.status(400).json({ message: "All fields are required." });
        }

        // Create a new goal
        const newGoal = new FinancialGoal({
            userId: req.user.userId, // Assuming req.user.id is populated by a middleware (e.g., JWT auth)
            name,
            targetAmount,
            startDate,
            endDate,
            category,
        });

        const savedGoal = await newGoal.save();
        res.status(201).json({ message: "Financial goal created successfully!", goal: savedGoal });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Internal server error." });
    }
}

const getGoals = async (req, res) => {
    try {
        const goals = await FinancialGoal.find({ userId: req.user.userId });
        if (!goals.length) {
            return res.status(404).json({ message: 'No budgets found for this user' });
        }
        res.status(200).json(goals);
    } catch (error) {
        res.status(500).json({ message: "Internal server error." });
    }
};

const updateGoal = async (req, res) => {
    const { id } = req.params;
    const  { name, targetAmount, startDate, endDate, category } = req.body;
    try {
        const goal = await FinancialGoal.findOneAndUpdate(
            { _id: id },
            { name, targetAmount, startDate, endDate, category },
            { new: true }
        );
        if (!goal)
            return res.status(404).json({ message: "Goal not found." });
        res.status(200).json({ message: "Goal updated successfully.", goal });
    } catch (error) {
        res.status(500).json({ message: "Internal server error." });
    }
};

const deleteGoal = async (req, res) => {
    const { id } = req.params;
    try {
      const goal = await FinancialGoal.findByIdAndDelete(id);
      if (!goal) {
        return res.status(404).json({ message: "Goal not found." });
      }
      res.status(200).json({ message: "Goal deleted successfully." });
    } catch (error) {
        console.error('Error deleting Expense:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
  };

  const deleteBudget = async (req, res) => {
    const { id } = req.params;
    try {
      const goal = await Budget.findByIdAndDelete(id);
      if (!goal) {
        return res.status(404).json({ message: "Budget not found." });
      }
      res.status(200).json({ message: "Budget deleted successfully." });
    } catch (error) {
        console.error('Error deleting Budget:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
  };



module.exports = {
    createBudget,
    getUserBudgets,
    updateBudget,
    createGoal,
    getGoals,
    updateGoal,
    deleteGoal,
    deleteBudget,
};