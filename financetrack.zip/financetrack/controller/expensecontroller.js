const express = require('express');
const register = require('../models/register.js');
const Expense = require('../models/expense.js');

const Expenseadd = async (req, res) => {
    const { amount, category, description, date } = req.body;

    try {
        const Expenses = new Expense({
            userId: req.userId, // Extracted from JWT token
            amount,
            category,
            description,
            date,
        });

        await Expenses.save();
        res.status(201).json({ message: 'Expense record added', Expenses });
    } catch (error) {
        console.error('Error adding income:', error);
        res.status(500).json({ message: 'Internal server error' });
    }

}

const getExpense = async (req,res) => {
    try{
        const userId = req.userId;

        const Expenses = await Expense.find({ userId }); // Sort by date
        res.json({ Expenses });
    }catch(error){
       console.error("Error fetching incomes:", error);
        res.status(500).json({ message: "An error occurred while fetching incomes." });
    }
}


const Expenseupdate = async (req,res) =>{
    const { id } = req.params;
    const { amount, category, description, date } = req.body;
    try{

        const editdata = await Expense.findByIdAndUpdate(
            id,
            {
             amount, category, description, date 
            },
        );
        if(!editdata){
            return res.status(404).json({ message: 'Expense record not found' });
        }
        res.status(200).json({ message: 'Expense record updated', editdata });
    }catch(error){
        console.log("error",error.message);
        res.status(500).json({ message: "internal server error" });
    }
}

const Expensedel = async(req,res) =>{
    const {id} = req.params;
    try{

        const Expenses = await Expense.findByIdAndDelete(id);

        if (!Expenses) {
            return res.status(404).json({ message: 'Expense record not found' });
        }

        res.status(200).json({ message: 'Expense record deleted' });
    } catch (error) {
        console.error('Error deleting Expense:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};





module.exports = {
    Expenseadd,
    getExpense,
    Expenseupdate,
    Expensedel,
};