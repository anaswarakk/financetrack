const express = require('express');
const register = require('../models/register.js');
const Income = require('../models/income.js');
const Expense = require('../models/expense.js');
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path'); 

const income = async (req, res) => {
    const { amount, category, description, date } = req.body;
  
    try {
        console.log("incomeapi")
        const income = new Income({
            userId: req.userId, // Extracted from JWT token
            amount,
            category,
            description,
            date,
        });

        await income.save();
        res.status(201).json({ message: 'Income record added', income });
    } catch (error) {
        console.error('Error adding income:', error);
        res.status(500).json({ message: 'Internal server error' });
    }

}

// const getincome = async (req, res) => {
//     try {
//         const incomes = await Income.find({ userId: req.user.userId }).sort({ date: -1 }); // Sort by date
//         res.status(200).json({ incomes });
//     } catch (error) {
//         console.error('Error adding income:', message.error);
//         res.status(500).json({ message: 'Internal server error' });
//     }
// }
// API to fetch income records for the authenticated user
const getincome = async (req, res) => {
    try {
        const userId = req.userId;  // Get userId from authenticated request (after JWT validation)
       
        // Fetch income records from the database for the authenticated user
        const incomes = await Income.find({ userId });
        
        // Send the income records as a response
        res.json({ incomes });
    } catch (error) {
        console.error("Error fetching incomes:", error);
        res.status(500).json({ message: "An error occurred while fetching incomes." });
    }
};

const getincomes = async (req, res) => {
    try {
        const { fromDate, toDate, download } = req.body;
        const filter = { userId: req.userId };
        // console.log("userId is",filter);
        if (fromDate && toDate) {
            const startDate = new Date(fromDate);
            const endDate = new Date(toDate);
            startDate.setUTCHours(0, 0, 0, 0);
            endDate.setUTCHours(23, 59, 59, 999);
            filter.date = { $gte: startDate, $lte: endDate };
        }

        // Fetch incomes based on filter (if applicable)
        const incomes = await Income.find(filter).sort({ date: -1 });
        console.log("incomes",incomes);
        const isDownload = download === 'true';
        if (isDownload) {
            console.log("isdownload");

            // Generate CSV data dynamically (streaming)
            const filePath = path.join(__dirname, 'incomes.csv');
            const ws = fs.createWriteStream(filePath);

            // Write CSV headers
            ws.write('Date,Category,Amount,Description\n');

            // Write each income record to the CSV file
            incomes.forEach((income) => {
                ws.write(
                    `${income.date.toISOString()},
                    ${income.category},
                    ${income.amount},
                    ${income.description}\n`
                );
            });

            // Close the stream once the file is fully written
            ws.end();

            // Handle response and streaming after file generation
            ws.on('finish', () => {
                // Set headers for file download after CSV generation
                res.header('Content-Type', 'text/csv');
                res.attachment('incomes.csv');

                // Stream the file to the client
                const readStream = fs.createReadStream(filePath);
                readStream.pipe(res);

                // Handle cleanup after file is streamed
                readStream.on('end', () => {
                    fs.unlink(filePath, (err) => {
                        if (err) console.error('Error deleting file:', err);
                    });
                });
            });

            return; // Prevent further execution
        }

        // If not downloading, send the data as JSON
        res.status(200).json({ incomes });
    } catch (error) {
        console.error("Error fetching income:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

const incomeupdate = async (req, res) => {
    const { id } = req.params;
    const { amount, category, description, date } = req.body;
    try {

        const editdata = await Income.findByIdAndUpdate(
            id,
            {
                amount, category, description, date
            },
        );
        if (!editdata) {
            return res.status(404).json({ message: 'Income record not found' });
        }
        res.status(200).json({ message: 'Income record updated', editdata });
    } catch (error) {
        console.log("error", error.message);
        res.status(500).json({ message: "internal server error" });
    }
}

const incomedel = async (req, res) => {
    const { id } = req.params;
    try {

        const income = await Income.findByIdAndDelete(id);

        if (!income) {
            return res.status(404).json({ message: 'Income record not found' });
        }

        res.status(200).json({ message: 'Income record deleted' });
    } catch (error) {
        console.error('Error deleting income:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};


const monthlysummary = async (req, res) => {
    const { fromDate, toDate } = req.body;

    try {
        if (!fromDate || !toDate) {
            return res.status(400).json({ message: "fromDate and toDate are required" });
        }

        // Parse and adjust the date range
        const startDate = new Date(fromDate);
        const endDate = new Date(toDate);

        startDate.setUTCHours(0, 0, 0, 0);
        endDate.setUTCHours(23, 59, 59, 999);

        console.log("Start Date (in UTC):", startDate);
        console.log("End Date (in UTC):", endDate);

        // Convert userId to ObjectId
        const userId = new mongoose.Types.ObjectId(req.user.userId);

        console.log("User ID from request:", userId);

        const [totalIncome, totalExpenses] = await Promise.all([
            Income.aggregate([
                {
                    $match: {
                        userId: userId,
                        date: {
                            $gte: startDate,
                            $lte: endDate
                        },
                    },
                },
                {
                    $group: {
                        _id: null,
                        totalAmount: { $sum: "$amount" },
                    },
                },
            ]),

            Expense.aggregate([
                {
                    $match: {
                        userId: userId,
                        date: {
                            $gte: startDate,
                            $lte: endDate
                        },
                    },
                },
                {
                    $group: {
                        _id: null,
                        totalAmount: { $sum: "$amount" },
                    },
                },
            ]),
        ]);

        console.log("Income Aggregation Result:", totalIncome);
        console.log("Expense Aggregation Result:", totalExpenses);

        res.status(200).json({
            income: totalIncome[0]?.totalAmount || 0,
            expenses: totalExpenses[0]?.totalAmount || 0,
        });
    } catch (error) {
        console.error('Error in monthlysummary:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

const reportByCategory = async (req, res) => {
    const { fromDate, toDate, type } = req.body;
    try {
        if (!fromDate || !toDate || !type) {
            return res.status(400).json({ message: "fromDate, toDate, and type are required" });
        }
        //Converts the fromDate and toDate strings into JavaScript Date objects.
        const startDate = new Date(fromDate);
        const endDate = new Date(toDate);


        //fromDate = "2024-12-01" becomes 2024-12-01T00:00:00.000Z
        //toDate = "2024-12-31" becomes 2024-12-31T23:59:59.999Z
        startDate.setUTCHours(0, 0, 0, 0);
        endDate.setUTCHours(23, 59, 59, 999);

        console.log("Start Date (in UTC):", startDate);
        console.log("End Date (in UTC):", endDate);

        //Convert into a MongoDB ObjectId to use in database queries
        const userId = new mongoose.Types.ObjectId(req.user.userId);

        //If the type is "income", the function queries the Income collection; otherwise, it queries the Expense collection.
        const Model = type.toLowerCase() === "income" ? Income : Expense;
        const result = await Model.aggregate([
            {
                $match: {
                    userId: userId,
                    date: { $gte: startDate, $lte: endDate },
                },
            },
            {
                $group: {
                    _id: "$category", // Group by category
                    totalAmount: { $sum: "$amount" },
                },
            },
        ]);

        console.log("Category Aggregation Result:", result);

        res.status(200).json(result);
    } catch (error) {
        console.error('Error in reportByCategory:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

const reportGoalProgress = async (req, res) => {
    const { fromDate, toDate, goalAmount } = req.body;

    try {
        if (!fromDate || !toDate || !goalAmount) {
            return res.status(400).json({ message: "fromDate, toDate, and goalAmount are required" });
        }

        const startDate = new Date(fromDate);
        const endDate = new Date(toDate);

        startDate.setUTCHours(0, 0, 0, 0);
        endDate.setUTCHours(23, 59, 59, 999);

        console.log("Start Date (in UTC):", startDate);
        console.log("End Date (in UTC):", endDate);

        const userId = new mongoose.Types.ObjectId(req.user.userId);

        const [totalIncome, totalExpenses] = await Promise.all([
            Income.aggregate([
                {
                    $match: {
                        userId: userId,
                        date: { $gte: startDate, $lte: endDate },
                    },
                },
                {
                    $group: {
                        _id: null,
                        totalAmount: { $sum: "$amount" },
                    },
                },
            ]),
            Expense.aggregate([
                {
                    $match: {
                        userId: userId,
                        date: { $gte: startDate, $lte: endDate },
                    },
                },
                {
                    $group: {
                        _id: null,
                        totalAmount: { $sum: "$amount" },
                    },
                },
            ]),
        ]);

        const income = totalIncome[0]?.totalAmount || 0;
        const expenses = totalExpenses[0]?.totalAmount || 0;
        const savings = income - expenses;

        const progress = ((savings / goalAmount) * 100).toFixed(2);

        console.log("Goal Progress:", { income, expenses, savings, progress });

        res.status(200).json({
            income,
            expenses,
            savings,
            goalAmount,
            progress: `${progress}%`,
        });
    } catch (error) {
        console.error('Error in reportGoalProgress:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};





module.exports = {
    income,
    getincome,
    getincomes,
    incomeupdate,
    incomedel,
    monthlysummary,
    reportByCategory,
    reportGoalProgress,
};