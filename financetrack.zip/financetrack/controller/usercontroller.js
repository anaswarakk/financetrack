const express = require('express');
const register = require('../models/register.js');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const registerapi = async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const existingUser = await register.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "Email already in use" });
        }

        if (!name && !email && !password) {
            return res.status(401).json({ message: "name email and pasword are required" });
        }
        const hashedpass = await bcrypt.hash(password, 10);

        const data = await register({
            name: name,
            email: email, 
            password: hashedpass
        });
        data.save();

        res.status(200).json({message:"data saved succesfully"});

    } catch (error) {console.log("error",error.message);
        res.status(500).json({ message: "internal server error" });
    }

}

const refreshTokenApi = async (req, res) => {
    const { refreshToken } = req.body;

    if (!refreshToken) {
        return res.status(401).json({ message: "Refresh token is required" });
    }

    try {
        const decoded = jwt.verify(refreshToken, process.env.JWT_SECRET || 'your_jwt_secret_key');
        
        const accessToken = jwt.sign(
            { userId: decoded.userId, email: decoded.email },
            process.env.JWT_SECRET || 'your_jwt_secret_key',
            { expiresIn: '15m' }
        );

        res.status(200).json({ accessToken });
    } catch (error) {
        console.error("Error during refresh token:", error);
        res.status(400).json({ message: "Invalid or expired refresh token" });
    }
};


const loginapi = async (req, res) => {
    const { email, password } = req.body;

    try {
        console.log("Login attempt...");

        // Validate input
        if (!email || !password) {
            return res.status(400).json({ message: "Email and password are required" });
        }

        // Check if user exists in the database
        const user = await register.findOne({ email: email });
        if (!user) {
            return res.status(401).json({ message: "Invalid email or password" });
        }

        // Compare passwords
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: "Invalid email or password" });
        }

        // Generate an access token (short-lived)
        const accessToken = jwt.sign(
            { userId: user._id, email: user.email }, // Payload
            process.env.JWT_SECRET || "your_jwt_secret_key", // Secret key
            { expiresIn: "15m" } // Access token expiration (short-lived)
        );

        // Generate a refresh token (long-lived)
        const refreshToken = jwt.sign(
            { userId: user._id, email: user.email }, // Payload
            process.env.JWT_SECRET || "your_jwt_secret_key", // Secret key
            { expiresIn: "7d" } // Refresh token expiration (long-lived)
        );

        // Optionally, store the refresh token in the database or memory for future validation
        // For now, we'll return it in the response

        res.status(200).json({
            message: "Login successful",
            accessToken,  // Return the access token
            refreshToken, // Return the refresh token
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
            },
        });
        
    } catch (error) {
        console.error("Error during login:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

const profileapi = async (req, res) => {
    try {
        const userId = req.user.userId;  // Get the user ID from the JWT payload
        const user = await register.findById(userId).select('-password');

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        res.status(200).json({ user });
    } catch (error) {
        console.error("Error fetching profile:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

const profileedit = async (req, res) => {
    const { name, email, phoneNumber, address, profilePicture } = req.body;
    
    try {
        const userId = req.user.userId;  // Get the user ID from the JWT payload
        const user = await register.findById(userId);

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        // Update user profile details
        user.name = name || user.name;
        user.email = email || user.email;
        user.phoneNumber = phoneNumber || user.phoneNumber;
        user.address = address || user.address;
        user.profilePicture = profilePicture || user.profilePicture;

        await user.save();

        res.status(200).json({
            message: "Profile updated successfully",
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                phoneNumber: user.phoneNumber,
                address: user.address,
                profilePicture: user.profilePicture,
            },
        });
    } catch (error) {
        console.error("Error updating profile:", error);
        res.status(500).json({ message: "Internal server error" });
    }
};

const dashboard = async (req, res) => {
    // Ensure user is authenticated
    const accessToken = req.headers['authorization'];

    if (!accessToken) {
        return res.redirect('/login');
    }

    // Optionally, verify the token here if needed

    // Render the dashboard page
    res.render('dashboard'); // Make sure the dashboard.ejs file exists
};


module.exports = {
    registerapi,
    loginapi,
    profileapi,
    profileedit,
    refreshTokenApi,
    dashboard,
};