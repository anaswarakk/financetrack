const express = require('express');
const Notification = require('../models/notification.js');


const addNotification = async (req, res) => {
    const { title, message, date } = req.body;
  
    try {
      const notification = new Notification({
        userId: req.user.userId, 
        title,
        message,
        date,
      });
      await notification.save();
  
      res.status(201).json({ success: true, message: "Notification added successfully.", notification });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error adding notification.", error: error.message });
    }
  };
  // GET /notifications
const getNotifications = async (req, res) => {
 
  
    try {
      const notifications = await Notification.find({  userId: req.user.userId, isSent: false });
      res.status(200).json({ success: true, notifications });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error fetching notifications.", error: error.message });
    }
  };
  const deleteNotification = async (req, res) => {
    const { id } = req.params;
  
    try {
      const result = await Notification.findByIdAndDelete(id);
      if (!result) {
        return res.status(404).json({ success: false, message: "Notification not found." });
      }
      res.status(200).json({ success: true, message: "Notification deleted successfully." });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error deleting notification.", error: error.message });
    }
  };

module.exports = {
    addNotification,
    getNotifications,
    deleteNotification
};