const express = require('express');
const Loan = require('../models/loans.js');

// POST /investment
const addloans = async (req, res) => {
    const { principal, interestRate, tenure, startDate, dueDate } = req.body;
  
    try {
        const loan = new Loan({
            userId:req.user.userId,
            principal,
            interestRate,
            tenure,
            startDate,
            dueDate,
            payments: [],
            status: 'active',
          });
      
          await loan.save();
          res.status(201).json({ message: 'Loan created successfully', loan });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error adding investment.", error: error.message });
    }
  };
  
 
  const getloans = async(req,res) =>{
    try {
        const loans = await Loan.find({ userId: req.user.userId });
    
        if (!loans.length) {
          return res.status(404).json({ message: 'No loans found for this user' });
        }
    
        res.status(200).json(loans);
      } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching loans', error });
      }
    };


    const loanIdpayment = async (req, res) => {
        try {
          const { amount, date } = req.body;
          const loanId = req.params.loanId; // Get the loanId from the URL
          console.log("Received loanId:", loanId); // Log the received loanId
      
          // Find the loan by its _id (MongoDB's default identifier for documents)
          const loan = await Loan.findById(loanId);
          console.log("Found loan:", loan); // Log the loan if found
      
          if (!loan) {
            return res.status(404).json({ message: 'Loan not found' });
          }
      
          // Add the payment to the payments array
          loan.payments.push({ amount, date });
      
          // Update the loan status if all payments are made or if it's overdue
          const totalPaid = loan.payments.reduce((sum, payment) => sum + payment.amount, 0);
          if (loan.status !== 'defaulted' && totalPaid >= loan.principal) {
            loan.status = 'closed'; // Mark loan as closed if the total payments cover the principal
          }
      
          // Save the updated loan document
          await loan.save();
      
          res.status(200).json({ message: 'Payment added successfully', loan });
        } catch (error) {
          console.error(error);
          res.status(500).json({ message: 'Error making payment', error: error.message });
        }
      };
      
// Update loan status (e.g., mark loan as closed or defaulted)
// Update loan status (e.g., mark loan as closed or defaulted)
const loanIdstatus = async (req, res) => {
    try {
      const { status } = req.body; // expected status: 'active', 'closed', 'defaulted'
  
      // Find the loan by userId instead of _id (use findOne to query by userId)
      const loan = await Loan.findOne({ userId: req.user.userId });
  
      if (!loan) {
        return res.status(404).json({ message: 'Loan not found' });
      }
  
      // Update the loan status
      loan.status = status;
      await loan.save();
  
      res.status(200).json({ message: 'Loan status updated', loan });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error updating loan status', error });
    }
  };
  

  const deleteloan = async (req, res) => {
    try {
      const loan = await Loan.findByIdAndDelete({ userId: req.user.userId });
  
      if (!loan) {
        return res.status(404).json({ message: 'Loan not found' });
      }
  
      res.status(200).json({ message: 'Loan deleted successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error deleting loan', error });
    }
  };
  // Get loan details by loanId
  const getloandetails = async (req, res) => {
    try {
      // Query the loan by userId
      const loan = await Loan.findOne({ userId: req.user.userId });
  
      if (!loan) {
        return res.status(404).json({ message: 'Loan not found' });
      }
  
      res.status(200).json(loan);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error fetching loan details', error });
    }
  };
  

  module.exports ={
    addloans,
    getloans,
    loanIdpayment,
    loanIdstatus,
    deleteloan,
    getloandetails,
  }
  