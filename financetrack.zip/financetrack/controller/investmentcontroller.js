const express = require('express');
const Investment = require('../models/investment.js');

// POST /investment
const addInvestment = async (req, res) => {
    const { investment_type, amount, date, description } = req.body;
  
    try {
      const investment = new Investment({
        userId: req.userId, 
        investment_type,
        amount,
        date,
        description,
        maturity_date
      });
      await investment.save();
  
      res.status(201).json({ success: true, message: "Investment added successfully.", investment });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error adding investment.", error: error.message });
    }
  };
  
 
  const getinvestment = async(req,res) =>{
    try{
        const Investments = await Investment.find({ userId: req.user.userId }).sort({ date: -1 }); // Sort by date
        console.log("Investments",Investments);
        res.status(200).json({ success: true, Investments });

    }catch(error){
        res.status(500).json({ success: false, message: "Error adding investment.", error: error.message });
    }
  }

  // PUT /investment/:id
const updateInvestment = async (req, res) => {
    const { id } = req.params;
    const { investment_type, amount, date, description, current_value } = req.body;
  
    try {
      const investment = await Investment.findByIdAndUpdate(
        id,
        { investment_type, amount, date, description, current_value,maturity_date },
        { new: true } // Return the updated document
      );
  
      if (!investment) {
        return res.status(404).json({ success: false, message: "Investment not found." });
      }
  
      res.status(200).json({ success: true, message: "Investment updated successfully.", investment });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error updating investment.", error: error.message });
    }
  };

  const calculateReturns = async (req, res) => {
    const { id } = req.params;
  
    try {
      const investment = await Investment.findById(id);
  
      if (!investment) {
        return res.status(404).json({ success: false, message: "Investment not found." });
      }
  
      const returns = investment.current_value - investment.amount; // Calculate returns
      res.status(200).json({ success: true, returns, investment });
    } catch (error) {
      res.status(500).json({ success: false, message: "Error calculating returns.", error: error.message });
    }
  };
  

  module.exports ={
    addInvestment,
    getinvestment,
    updateInvestment,
    calculateReturns,
  }
  