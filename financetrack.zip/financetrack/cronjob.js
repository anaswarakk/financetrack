const cron = require("node-cron");
const Notification = require("./models/notification.js");
const { sendEmailNotification, sendSmsNotification } = require('./notificationservice.js');

// Schedule the cron job to run every minute
// Schedule the cron job to run every minute
const scheduleNotificationsCron = () => {
    cron.schedule("* * * * *", async () => {
      console.log("Checking for due notifications...");
  
      try {
        const now = new Date();
        const notifications = await Notification.find({ date: { $lte: now }, isSent: false });
  
        notifications.forEach(async (notification) => {
          // Check the type of notification and send accordingly
          if (notification.type === "email") {
            await sendEmailNotification(notification);
          } else if (notification.type === "sms") {
            await sendSmsNotification(notification);
          }
  
          // Mark the notification as sent
          notification.isSent = true;
          await notification.save();
        });
      } catch (error) {
        console.error("Error checking notifications:", error.message);
      }
    });
  };
  
  module.exports = { scheduleNotificationsCron };
