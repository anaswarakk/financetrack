const express = require('express');
const router = express();
const {registerapi,loginapi,profileapi,profileedit,refreshTokenApi,dashboard} = require('../controller/usercontroller.js');
const {income,getincome,getincomes,incomeupdate,incomedel,monthlysummary,reportByCategory,reportGoalProgress} =  require('../controller/incomecontroller.js');
const {Expenseadd,getExpense,Expenseupdate,Expensedel} =  require('../controller/expensecontroller.js');
const {createBudget,getUserBudgets,updateBudget,createGoal,getGoals,updateGoal,deleteGoal,deleteBudget} =  require('../controller/budgetcontroller.js');
const {addNotification,getNotifications,deleteNotification} = require('../controller/notificationcontroller.js');
const {addInvestment,getinvestment,updateInvestment,calculateReturns} = require('../controller/investmentcontroller.js');
const {addloans,getloans,loanIdpayment,loanIdstatus,deleteloan,getloandetails} = require('../controller/loancontroller.js');

const verifyToken = require('../middleware/auth');

//http://localhost:8001/register
// {
//     "name":"anaswara",
//     "email": "anaswaraanu155@gmail.com",
//     "password": "Anu@123"
//   }
router.get('/registers', (req, res) => {
    res.render('register');  // This will render the 'login.ejs' file
});
router.post('/register',registerapi);

// Serve the login page (GET request)
router.get('/login', (req, res) => {
    res.render('login');  // This will render the 'login.ejs' file
});
router.post('/login',loginapi);
router.get('/getincome',verifyToken,getincome);
router.get('/', (req, res) => {
    // You can send user data here if needed, e.g., user name, email, etc.
    res.render('dashboard'); // Renders the dashboard.ejs
});
router.get('/report', (req, res) => {
    // You can send user data here if needed, e.g., user name, email, etc.
    res.render('reports'); // Renders the dashboard.ejs
});

router.get('/income', (req, res) => {
    // You can send user data here if needed, e.g., user name, email, etc.
    res.render('incomedetails'); // Renders the dashboard.ejs
});
//http://localhost:8001/income
//{"amount":"4900","date":"2024-01-03", "description": " salary","category":"freelance","userId":"676104f29d394c305789d988"}
router.post('/income',verifyToken,income);
router.get('/getincomes',verifyToken,getincomes);
router.get('/incomeupdate/:id',verifyToken,incomeupdate);
//http://localhost:8001/incomedel/675695382a1967d5d6dbc329
router.delete('/incomedel/:id',verifyToken,incomedel);

// router.post('/dashboard',dashboard);
//add bearer token in the header
router.get('/profile',verifyToken,profileapi);
router.get('/profileedit',verifyToken,profileedit);
router.post('/refresh-token', refreshTokenApi);


router.get('/Expense', (req, res) => {
    // You can send user data here if needed, e.g., user name, email, etc.
    res.render('expensedetails'); // Renders the dashboard.ejs
});
// http://localhost:8001/Expenseadd
router.post('/Expenseadd',verifyToken,Expenseadd);
//http://localhost:8001/getExpense
router.get('/getExpense',verifyToken,getExpense);
router.get('/Expenseupdate/:id',verifyToken,Expenseupdate);
//http://localhost:8001/incomedel/675695382a1967d5d6dbc329
router.delete('/Expensedel/:id',verifyToken,Expensedel);

router.get('/Budget', (req, res) => {
    // You can send user data here if needed, e.g., user name, email, etc.
    res.render('budgetdetails'); // Renders the dashboard.ejs
});
// http://localhost:8001/createBudget
// {"amount":"300","category":"Groceries","startDate":"2024-12-08","endDate":"2024-12-09","description":""}
router.post('/createBudget',verifyToken,createBudget );
//http://localhost:8001/getUserBudgets
router.get('/getUserBudgets',verifyToken,getUserBudgets );
router.get('/updateBudget/:id',verifyToken,updateBudget );

// http://localhost:8001/createGoal
// {"targetAmount":"10000","category":"Travel","startDate":"2024-12-07","endDate":"2024-12-08","name":"Vacation Saving"}
router.post('/createGoal',verifyToken,createGoal);
router.post('/getGoals',verifyToken,getGoals);
router.post('/updateGoal/:id',verifyToken,updateGoal);
router.delete('/deleteGoal/:id',verifyToken,deleteGoal);
router.delete('/deleteBudget/:id',verifyToken,deleteBudget);


router.post('/monthlysummary',verifyToken,monthlysummary);
//http://localhost:8001/reportByCategory
// {"fromDate":"2024-12-07","toDate":"2024-12-09", "type": "expense"}
router.post('/reportByCategory',verifyToken,reportByCategory);
router.post('/reportGoalProgress',verifyToken,reportGoalProgress);


router.post('/addNotification',verifyToken,addNotification);
router.get('/getNotifications',verifyToken,getNotifications);
router.get('/deleteNotification',verifyToken,deleteNotification);

// {
//     "date": "2024-12-11",
//     "investment_type": "sip",
//     "amount": "1500",
//     "description":"elss tax fund",
//     "current_value":"80"
// }
router.post('/addInvestment',verifyToken,addInvestment);
router.get('/getinvestment',verifyToken,getinvestment);
router.post('/updateInvestment/:id',verifyToken,updateInvestment);
router.get('/calculateReturns/:id',verifyToken,calculateReturns);


router.post('/addloans',verifyToken,addloans);
router.get('/getloans',verifyToken,getloans);
router.post('/loanIdpayment/:id',verifyToken,loanIdpayment);
router.get('/loanIdstatus',verifyToken,loanIdstatus);
router.get('/deleteloan',verifyToken,deleteloan);
router.get('/getloandetails',verifyToken,getloandetails);

module.exports = router;
