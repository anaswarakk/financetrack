const nodemailer = require("nodemailer");
// const twilio = require("twilio");

// Setup Nodemailer transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "your-email@gmail.com",
    pass: "your-email-password",
  },
});

// Setup Twilio client
// const twilioClient = new twilio('TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN');

// Function to send email
const sendEmailNotification = async (notification) => {
  const mailOptions = {
    from: "your-email@gmail.com",
    to: notification.email, // Assuming notification contains the recipient's email
    subject: notification.title,
    text: notification.message,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log("Email sent successfully!");
  } catch (error) {
    console.error("Error sending email:", error.message);
  }
};

// Function to send SMS via Twilio
// const sendSmsNotification = async (notification) => {
//   try {
//     const message = await twilioClient.messages.create({
//       body: notification.message,
//       to: notification.phone, // Assuming notification contains the recipient's phone number
//       from: 'your-twilio-phone-number',
//     });
//     console.log("SMS sent successfully!");
//   } catch (error) {
//     console.error("Error sending SMS:", error.message);
//   }
// };

// Export the functions
module.exports = { sendEmailNotification };
